# TIGON-IQ Chatbot - Setup Guide for Replit

## Overview
This is a customer service chatbot system for TIGON Golf Carts with AI-powered responses, real-time chat via WebSockets, and a full-featured dashboard.

## Issues Fixed
The original code had several critical issues that prevented it from working:

1. **Invalid OpenAI Model**: Used non-existent "gpt-5" model
2. **Invalid API Calls**: Used non-existent `openai.responses.create()` API
3. **Missing Error Handling**: Poor error handling for API failures
4. **Environment Variables**: Unclear setup instructions

All issues have been resolved. See `FIXES_APPLIED.md` for details.

## Prerequisites

1. **Neon Database Account** (Free tier available)
   - Sign up at: https://neon.tech
   - Create a new project
   - Copy the connection string

2. **OpenAI API Key**
   - Sign up at: https://platform.openai.com
   - Create an API key
   - Ensure you have credits available

## Setup Instructions for Replit

### Step 1: Set Environment Variables

In Replit, go to the "Secrets" tab (lock icon) and add these variables:

```
DATABASE_URL=postgresql://user:password@host/database?sslmode=require
OPENAI_API_KEY=sk-your-api-key-here
PORT=5000
NODE_ENV=production
SESSION_SECRET=your-random-secret-string
```

**Important:** 
- Replace `DATABASE_URL` with your actual Neon connection string
- Replace `OPENAI_API_KEY` with your actual OpenAI API key
- Generate a random string for `SESSION_SECRET`

### Step 2: Install Dependencies

Run in the Replit shell:
```bash
npm install
```

### Step 3: Initialize Database

Run database migrations:
```bash
npm run db:push
```

### Step 4: Start the Application

Click the "Run" button in Replit, or run:
```bash
npm run dev
```

The application will start on port 5000.

## Features

### For Customers
- Real-time chat interface
- AI-powered responses about TIGON products
- Seamless handoff to human representatives when needed
- Email notifications for new conversations

### For Representatives/Admins
- Dashboard with conversation management
- Real-time message notifications
- Conversation history and analytics
- Settings management for AI and email

## Architecture

- **Frontend**: React + TypeScript + Tailwind CSS
- **Backend**: Express.js + TypeScript
- **Database**: PostgreSQL (Neon serverless)
- **Real-time**: WebSockets (ws library)
- **AI**: OpenAI GPT-4o-mini
- **Build Tool**: Vite

## API Endpoints

### Public Endpoints
- `POST /api/conversations` - Create new conversation
- `GET /api/widget-config` - Get chatbot widget configuration

### Protected Endpoints (require authentication)
- `GET /api/conversations` - List all conversations
- `GET /api/conversations/:id` - Get conversation details
- `PATCH /api/conversations/:id` - Update conversation
- `GET /api/stats` - Get dashboard statistics
- `GET /api/settings` - Get system settings
- `PATCH /api/settings` - Update system settings

### WebSocket Events
- `join_conversation` - Join a conversation room
- `send_message` - Send a chat message
- `typing` - Broadcast typing indicator
- `new_message` - Receive new messages
- `joined` - Confirmation of joining conversation

## Troubleshooting

### Database Connection Issues
- Verify `DATABASE_URL` is correct
- Ensure your Neon database is active
- Check that SSL mode is enabled in connection string

### OpenAI API Issues
- Verify `OPENAI_API_KEY` is valid
- Check you have available credits
- Review error logs for specific API errors

### Port Issues
- Replit should automatically handle port forwarding
- Ensure `PORT=5000` is set in environment variables
- Check that no other service is using port 5000

### WebSocket Connection Issues
- Ensure the WebSocket path is `/ws`
- Check CORS settings allow your domain
- Verify the server is running before connecting

## Development vs Production

### Development Mode
```bash
npm run dev
```
- Uses `tsx` for hot reloading
- Vite dev server for frontend
- Detailed error logging

### Production Mode
```bash
npm run build
npm start
```
- Compiled JavaScript
- Optimized frontend bundle
- Production error handling

## Support

For issues specific to this chatbot:
1. Check `FIXES_APPLIED.md` for known issues
2. Review error logs in Replit console
3. Verify all environment variables are set correctly

For TIGON Golf Carts business inquiries:
- Call: 1-844-844-6638
- Visit: https://tigongolfcarts.com

## License
MIT
